import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileProcessor {
    private static LinkedListCustom number1;
    private static LinkedListCustom number2;
    private static String operation;


    public FileProcessor() {
        number1 = new LinkedListCustom();
        number2 = new LinkedListCustom();
    }

    /**
     * Processes arithmetic expressions line-by-line in the given file.
     *
     * @param filePath Path to a file containing arithmetic expressions.
     */
    public static void processFile(String filePath) {
        File infile = new File(filePath);

        try {
            Scanner scan = new Scanner(infile);


            String output = null;
            while (scan.hasNext()) {

                number1 = new LinkedListCustom(); // Clear the existing linked lists
                number2 = new LinkedListCustom();

                String line = scan.nextLine();
                line = line.replaceAll("\\s", "").replaceAll("\\b0+(?!\\b)", "");

                StringBuilder num1 = new StringBuilder();
                StringBuilder operator = new StringBuilder();
                boolean isOperator = false;

                if (!line.isEmpty()) {
                    for (char c : line.toCharArray()) {
                        if (Character.isDigit(c)) {
                            if (isOperator) {
                                operator.append(c);
                            } else {
                                num1.append(c);
                            }
                        } else {
                            isOperator = true;
                            operator.append(c);
                        }
                    }
                } else {
                    continue;
                }
                String numb1 = num1.substring(0);
                String num2 = operator.substring(1);
                operation = operator.substring(0, 1);


                // Convert the digits of num1 and num2 into linked lists

                String flippednumb1 = new StringBuilder(numb1).reverse().toString();
                String flippednum2 = new StringBuilder(num2).reverse().toString();

                number1 = stringToList(flippednumb1);
                number2 = stringToList(flippednum2);

                output = "";
                System.out.println(number1.numberAsLinkedListString());
                System.out.println(operation);
                System.out.println(number2.numberAsLinkedListString());


                if (operation.equals("+")) {
                    output = Addition(number1, number2);
                } else if (operation.equals("*")) {
                    output = Multiplication(number1, number2);
                }
                else if (operation.equals("^")) {
                    long temp = 0;
                    Node current2 = number2.head;
                    Node current1 = number1.head;
                    int n = 0;
                    long x = 0;
                    int iter = 0;
                    while (current2 != null) {
                        n += (int) (current2.value * Math.pow(10, iter));
                        current2 = current2.next;
                        iter++;
                    }
                    iter = 0;
                    while (current1 != null) {
                        x += (int) (current1.value * Math.pow(10, iter));
                        current1 = current1.next;
                        iter++;
                    }

                    temp = Exponent(x, n);
                    output = Long.toString(temp);
                }
                System.out.println(output);

            }



            scan.close(); // Close the scanner when done
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + infile.getPath());
        }
    }

    public LinkedListCustom getNumber1() {
        return number1;
    }

    public LinkedListCustom getNumber2() {
        return number2;
    }

    public String getOperator() {
        return operation;
    }

    public static LinkedListCustom stringToList(String relevant) {
        LinkedListCustom out = new LinkedListCustom();
        for (char c : relevant.toCharArray()) {
           // System.out.print(c);
            int digit = Character.getNumericValue(c);
            out.insertDigit(digit);
        }
        return out;
    }

    public static LinkedListCustom stringToReverseList(String relevant) {
        LinkedListCustom out = new LinkedListCustom();
        StringBuilder temp = new StringBuilder(relevant);
        relevant = temp.reverse().toString();
        for (char c : relevant.toCharArray()) {
            // System.out.print(c);
            int digit = Character.getNumericValue(c);
            out.insertDigit(digit);
        }
        return out;
    }

    public static String Addition(LinkedListCustom numbe1, LinkedListCustom numbe2) {
        String output = "";
        Node current1 = numbe1.head;
        Node current2 = numbe2.head;
        int carryover = 0;

        while (current1 != null || current2 != null) {
            int tempNum1 = (current1 != null) ? current1.value : 0;
            int tempNum2 = (current2 != null) ? current2.value : 0;
            int ones = tempNum1 + tempNum2 + carryover;
            if (ones >= 10) {
                carryover = ones / 10;
                ones = ones % 10;
            } else {
                carryover = 0;
            }
            String temp = Integer.toString(ones);
            output = temp + output;
            current1 = (current1 != null) ? current1.next : null;
            current2 = (current2 != null) ? current2.next : null;
        }
        return output;
    }

    public static String Multiplication(LinkedListCustom numbe1, LinkedListCustom numbe2) {
        Node current1 = number1.head;
        Node current2 = numbe2.head;
        int iter = 0;
        int topNum = 0;
        int answer = 0;

        while (current1 != null) {
            topNum += (int) (current1.value * Math.pow(10, iter));
            current1 = current1.next;
            iter++;
        }
        iter = 0;
        while (current2 != null) {
            answer += (int) Math.pow(10, iter) * topNum * current2.value;
            iter++;
            current2 = current2.next;
        }
        return Integer.toString(answer);
    }

    public static long Exponent(long x, int n) {
        if(n < 0) {
            return Exponent(1 / x, n);
        } else if (n == 0) {
            return 1;
        } else if (n % 2 == 0) {
            return Exponent(x * x, n / 2);
        } else { // if n is odd
            return x * Exponent(x * x, (n - 1) / 2);
        }
    /* public static LinkedListCustom Exponent(LinkedListCustom numbe1, int n) {
        System.out.println("number 1: " + numbe1.listAsSimpleString() + ", n: " + n);
       // LinkedListCustom tester = new LinkedListCustom();
       // tester.insertDigit(1);
        //System.out.println(Multiplication(numbe1, tester));
        //System.out.println(Multiplication(numbe1, numbe1));
        LinkedListCustom outList = new LinkedListCustom();
        if (n == 0) {
            outList.insertDigit(1);
            return outList;
        } else if (n % 2 == 0) {
            outList = Exponent((stringToReverseList(Multiplication(numbe1, numbe1))), n / 2);
            System.out.println("outlist: " + outList.listAsSimpleString());
            return outList;
        } else { // if n is odd
            outList = stringToReverseList(Multiplication(numbe1, Exponent(stringToReverseList(Multiplication(numbe1, numbe1)), (n - 1) / 2)));
            System.out.println("outlist: " + outList.listAsSimpleString());
            return outList;
        } */
    }
}
