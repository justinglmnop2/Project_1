public class Node {

    int value;
    Node next;

    Node(int x, Node node) {
        value = x;
        next = null;
    }
}
