import org.junit.jupiter.api.Test;

import java.io.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Tests {

    @Test
    public void testProcessFile() {
        // Prepare a test file with content "100 + 782"
        String testFilePath = "test_input.txt";
        try {
            FileWriter fileWriter = new FileWriter(testFilePath);
            fileWriter.write("100 + 782");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Capture the output and verify the linked lists
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        FileProcessor.processFile(testFilePath);

        // Verify the linked lists directly
        assertEquals("0 -> 0 -> 1", number1AsLinkedListString(FileProcessor.getNumber1()));
        assertEquals("2 -> 8 -> 7", number2AsLinkedListString(FileProcessor.getNumber2()));

        // Clean up by deleting the test file
        File testFile = new File(testFilePath);
        if (testFile.exists()) {
            testFile.delete();
        }
    }

    private String number1AsLinkedListString(LinkedListCustom linkedList) {
        StringBuilder result = new StringBuilder();

        Node current = linkedList.head;
        while (current != null) {
            result.append(current.value);
            if (current.next != null) {
                result.append(" -> ");
            }
            current = current.next;
        }

        return result.toString();
    }
    

    private String number2AsLinkedListString(LinkedListCustom linkedList) {
        StringBuilder result = new StringBuilder();

        Node current = linkedList.head;
        while (current != null) {
            result.append(current.value);
            if (current.next != null) {
                result.append(" -> ");
            }
            current = current.next;
        }

        return result.toString();
    }
}
