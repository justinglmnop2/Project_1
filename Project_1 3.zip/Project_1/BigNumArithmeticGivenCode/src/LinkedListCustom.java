public class LinkedListCustom {
    static Node head;

    public LinkedListCustom() {
    }


    public void insertDigit(int digit) {
        Node newNode = new Node(digit, new Node(1, null));
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }


}
