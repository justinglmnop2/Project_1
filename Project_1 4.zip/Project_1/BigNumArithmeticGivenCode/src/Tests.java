import org.junit.jupiter.api.Test;

import java.io.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Tests {

    @Test
    public void testToString() {
        LinkedListCustom test = new LinkedListCustom();
        test.insertDigit(0);
        test.insertDigit(0);
        test.insertDigit(1);
        assertEquals("0 -> 0 -> 1", test.numberAsLinkedListString());
    }

    @Test
    public void testProcessFile() {
        // Prepare a test file with content "100 + 782"
        String testFilePath = "test_input.txt";
        try {
            FileWriter fileWriter = new FileWriter(testFilePath);
            fileWriter.write("100 + 782");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        FileProcessor f = new FileProcessor();
        f.processFile("test_input.txt");

    }

    public String numberAsLinkedListString(LinkedListCustom l) {
        StringBuilder result = new StringBuilder();

        Node current = LinkedListCustom.head;
        while (current != null) {
            result.append(current.value);
            if (current.next != null) {
                result.append(" -> ");
            }
            current = current.next;
        }

        return result.toString();
    }

}
