import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileProcessor {

    /**
     * Processes arithmetic expressions line-by-line in the given file.
     *
     * @param filePath Path to a file containing arithmetic expressions.
     */
    public static void processFile(String filePath) {
        File infile = new File(filePath);
        try (Scanner scan = new Scanner(infile)) {
            while (scan.hasNext()) {
                // TODO: Process each line of the input file here.
                String line = scan.nextLine();
                // removes whitespaces and handles leading zeros
                line = line.replaceAll("\\s","").replaceAll("\\b0+(?!\\b)","");

                StringBuilder num1 = new StringBuilder();
                StringBuilder operator = new StringBuilder();

                boolean isOperator = false;
                if (!line.isEmpty()) {
                    for (char c : line.toCharArray()) {
                        if (Character.isDigit(c)) {
                            if (isOperator) {
                                operator.append(c);
                            } else {
                                 num1.append(c);
                            }
                        } else {
                            isOperator = true;
                            operator.append(c);
                        }
                    }
                }
                String num2 = operator.substring(1);
                String operation = operator.substring(0,1);
                BigNumArithmetic number1 = new BigNumArithmetic(Integer.parseInt(String.valueOf(num1)));
                BigNumArithmetic number2 = new BigNumArithmetic(Integer.parseInt(String.valueOf(num2)));
            }

            //System.out.println(number1 + operation + number2);
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + infile.getPath());
        }
    }
}
